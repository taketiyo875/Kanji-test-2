(() => {
  "use strict";
  const DATA_URL = "./kanji-data.json";
  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => Array.from(document.querySelectorAll(selector));
  const state = { mode: "reading", characters: [], questions: [], questionIndex: 0, answered: false, loaded: false };
  const normalize = (value) => String(value ?? "").normalize("NFKC").trim().replace(/[\s　・、，,。．.]/g, "").toLowerCase();
  const readingVariants = (value) => {
    const text = normalize(value);
    return new Set([text, text.replace(/[\u30a1-\u30f6]/g, ch => String.fromCharCode(ch.charCodeAt(0) - 0x60)), text.replace(/[\u3041-\u3096]/g, ch => String.fromCharCode(ch.charCodeAt(0) + 0x60))]);
  };
  const sameReading = (a, b) => { const av = readingVariants(a); return [...readingVariants(b)].some(x => av.has(x)); };
  const getReadings = (record) => {
    const r = record?.readings;
    if (Array.isArray(r)) return r.filter(x => typeof x === "string" && x.trim());
    if (!r || typeof r !== "object") return [];
    return [...(Array.isArray(r.on) ? r.on : []), ...(Array.isArray(r.kun) ? r.kun : [])].filter(x => typeof x === "string" && x.trim());
  };
  const setText = (selector, value) => { const el = $(selector); if (el) el.textContent = value; };
  const show = (selector) => { const el = $(selector); if (el) el.hidden = false; };
  const hide = (selector) => { const el = $(selector); if (el) el.hidden = true; };
  async function loadData() {
    try {
      const response = await fetch(DATA_URL, { cache: "no-store" });
      if (!response.ok) throw new Error("kanji-data.json が見つかりません。");
      const data = await response.json();
      const records = Array.isArray(data) ? data : data.characters;
      if (!Array.isArray(records)) throw new Error("漢字データの形式を確認できません。");
      state.characters = records.filter(x => x && typeof x.kanji === "string" && x.kanji.trim());
      state.loaded = true;
      setText("#browse-status", `${state.characters.length.toLocaleString("ja-JP")} 字のデータを読み込みました。`);
    } catch (error) {
      state.loaded = false;
      const message = `漢字データを読み込めませんでした。kanji-data.json が同じフォルダにあるか確認してください。${error.message ? `（${error.message}）` : ""}`;
      setText("#quiz-status", message); setText("#browse-status", message);
    }
  }
  function showHome() { hide("#quiz-panel"); hide("#browse-panel"); show("#home-panel"); if ($("#answer-input")) $("#answer-input").value = ""; state.answered = false; }
  function buildQuestions(mode) {
    if (mode === "reading") return state.characters.map(record => ({ type: "reading", prompt: record.kanji, answers: getReadings(record) })).filter(q => q.answers.length);
    const questions = [];
    state.characters.forEach(record => {
      if (!Array.isArray(record.examples)) return;
      record.examples.forEach(example => {
        // Example readings are required; blank readings are intentionally not guessed.
        if (example && typeof example.word === "string" && typeof example.reading === "string" && example.word.trim() && example.reading.trim()) questions.push({ type: "writing", prompt: example.reading, answer: example.word });
      });
    });
    return questions;
  }
  function showQuiz(mode) {
    state.mode = mode; state.questionIndex = 0; state.answered = false;
    hide("#home-panel"); hide("#browse-panel"); show("#quiz-panel"); hide("#question-card");
    setText("#quiz-title", mode === "reading" ? "読み問題" : "書き取り問題");
    if (!state.loaded) { setText("#quiz-status", "漢字データを読み込めていません。ファイルの配置を確認してください。"); return; }
    state.questions = buildQuestions(mode);
    if (!state.questions.length) {
      setText("#quiz-status", mode === "reading" ? "読み問題に使えるデータがありません。" : "書き取り問題の例語には読みが登録されていないため、現在は出題できません。読みが確認できた例語を登録すると利用できます。");
      return;
    }
    renderQuestion();
  }
  function renderQuestion() {
    const q = state.questions[state.questionIndex];
    if (!q) { hide("#question-card"); setText("#quiz-status", "全問終了！おつかれさま！メニューに戻って別の問題にも挑戦しよう。"); return; }
    state.answered = false; show("#question-card");
    setText("#question-label", state.mode === "reading" ? "この漢字の読みを入力してください" : "この読みを漢字で入力してください");
    setText("#question-character", q.prompt); setText("#answer-feedback", "");
    const input = $("#answer-input"); if (input) { input.value = ""; input.disabled = false; input.autocomplete = "off"; }
    const next = $("#next-question"); if (next) next.hidden = true;
    setText("#quiz-status", `問題 ${state.questionIndex + 1} / ${state.questions.length}`);
  }
  function checkAnswer(event) {
    event.preventDefault(); if (state.answered) return;
    const q = state.questions[state.questionIndex]; const input = $("#answer-input"); const answer = input?.value || "";
    if (!normalize(answer)) { setText("#answer-feedback", "答えを入力してください。"); return; }
    const correct = q.type === "reading" ? q.answers.some(expected => sameReading(answer, expected)) : normalize(answer) === normalize(q.answer);
    state.answered = true; if (input) input.disabled = true;
    const feedback = $("#answer-feedback");
    if (feedback) { feedback.textContent = correct ? "正解！すごい！🐾" : `おしい！答え：${q.type === "reading" ? q.answers.join("／") : q.answer}`; feedback.classList.toggle("correct", correct); feedback.classList.toggle("incorrect", !correct); }
    const next = $("#next-question"); if (next) { next.hidden = false; next.textContent = state.questionIndex + 1 >= state.questions.length ? "おしまい" : "次の問題へ"; }
  }
  function nextQuestion() { if (!state.answered) return; state.questionIndex++; renderQuestion(); }
  function openBrowse() { hide("#home-panel"); hide("#quiz-panel"); show("#browse-panel"); renderKanjiList($("#kanji-search")?.value || ""); }
  function renderKanjiList(searchText = "") {
    const list = $("#kanji-list"); if (!list) return; list.replaceChildren();
    if (!state.loaded) { setText("#browse-status", "漢字データを読み込めていません。kanji-data.json を同じフォルダに置いてください。"); return; }
    const query = normalize(searchText);
    const filtered = state.characters.filter(record => {
      const readings = getReadings(record).join(" ");
      const examples = Array.isArray(record.examples) ? record.examples.map(x => `${x.word || ""} ${x.reading || ""}`).join(" ") : "";
      return !query || normalize(`${record.kanji} ${readings} ${examples}`).includes(query);
    });
    setText("#browse-status", `${filtered.length.toLocaleString("ja-JP")} 件`);
    if (!filtered.length) { const empty = document.createElement("li"); empty.textContent = "一致する漢字がありません。"; list.appendChild(empty); return; }
    // Limit DOM size while searching/listing, keeping the interface responsive on phones.
    filtered.slice(0, 250).forEach(record => {
      const item = document.createElement("li");
      const character = document.createElement("strong"); character.className = "kanji-list-character"; character.textContent = record.kanji; item.appendChild(character);
      const details = document.createElement("div"); details.className = "kanji-list-details";
      const readings = getReadings(record); const line = document.createElement("p"); line.textContent = readings.length ? `読み：${readings.join("・")}` : "読み：データなし"; details.appendChild(line);
      if (Array.isArray(record.examples) && record.examples.length) { const ex = document.createElement("p"); ex.textContent = `例：${record.examples.slice(0, 5).map(x => x.word).filter(Boolean).join("、")}`; details.appendChild(ex); }
      item.appendChild(details); list.appendChild(item);
    });
    if (filtered.length > 250) { const more = document.createElement("li"); more.textContent = "表示を250件に制限しています。漢字や読みを検索すると絞り込めます。"; list.appendChild(more); }
  }
  function wireEvents() {
    $$('[data-mode="reading"]').forEach(button => button.addEventListener("click", () => showQuiz("reading")));
    $$('[data-mode="writing"]').forEach(button => button.addEventListener("click", () => showQuiz("writing")));
    $$('[data-mode="browse"]').forEach(button => button.addEventListener("click", openBrowse));
    $("#answer-form")?.addEventListener("submit", checkAnswer); $("#next-question")?.addEventListener("click", nextQuestion);
    $("#back-home")?.addEventListener("click", showHome); $("#browse-back-home")?.addEventListener("click", showHome);
    $("#kanji-search")?.addEventListener("input", event => renderKanjiList(event.target.value));
  }
  document.addEventListener("DOMContentLoaded", async () => { wireEvents(); await loadData(); });
})();
